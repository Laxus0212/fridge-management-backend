export class UpdateShoppingListDto {
  name?: string;
  familyId?: number; // Opcionális, ha a lista megosztva van a családdal
}
