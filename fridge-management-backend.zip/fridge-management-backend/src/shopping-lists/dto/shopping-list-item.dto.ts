export class ShoppingListItemDto {
  productName: string;
  quantity: number;
  unit: string; // 'kg', 'g', 'l', 'ml', 'pcs', 'dkg', 'dl'
}
