export enum Unit {
  GRAM = 'g',
  KILOGRAM = 'kg',
  MILLILITER = 'ml',
  LITER = 'l',
  PIECE = 'pcs',
  DEKAGRAM = 'dkg',
  DECILITER = 'dl',
}
