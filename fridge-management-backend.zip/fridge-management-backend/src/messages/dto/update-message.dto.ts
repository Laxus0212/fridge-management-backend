export class UpdateMessageDto {
  message: string;
}
