export class CreateMessageDto {
  chatId: number;
  senderId: number;
  username: string;
  message: string;
  familyId: number;
}
