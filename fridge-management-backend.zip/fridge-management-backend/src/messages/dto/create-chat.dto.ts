export class CreateChatDto {
  familyId: number;
}
