export class MessageResponseDto {
  messageId: string;
  chatId: number;
  senderId: number;
  username: string;
  message: string;
  sentAt: string;
  familyId: number;
}
