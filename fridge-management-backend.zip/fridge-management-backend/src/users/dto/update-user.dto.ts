// update-user.dto.ts
export class UpdateUserDto {
  email?: string;
  username?: string;
  password?: string;
  familyId?: number;
}
