// login-user.dto.ts
export class LoginUserDto {
  email: string;
  password: string;
}
