// update-fridge.dto.ts
export class UpdateFridgeDto {
  fridgeName?: string;
  familyId?: number;
}
