// create-fridge.dto.ts
export class CreateFridgeDto {
  fridgeName: string;
  ownerId: number;
  familyId: number;
}
