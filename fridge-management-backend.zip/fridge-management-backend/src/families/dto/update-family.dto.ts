// update-family.dto.ts
export class UpdateFamilyDto {
  familyName?: string;
}
