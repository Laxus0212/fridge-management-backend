// create-family.dto.ts
export class CreateFamilyDto {
  familyName: string;
}
