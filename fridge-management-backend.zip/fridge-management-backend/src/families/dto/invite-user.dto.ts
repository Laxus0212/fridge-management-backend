// invite-user.dto.ts
export class InviteUserDto {
  email: string;
}
