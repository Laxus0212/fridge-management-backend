export class UpdateRecipeDto {
  familyId?: number;
}
