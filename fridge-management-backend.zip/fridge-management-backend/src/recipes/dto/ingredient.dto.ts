export class IngredientDto {
  ingredient_name: string;
  quantity: number;
  unit: string; // 'g', 'kg', 'ml', 'l', 'pcs', 'dkg', 'dl'
}
