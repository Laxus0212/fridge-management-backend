// create-shelf.dto.ts
export class CreateShelfDto {
  shelfName: string;
  fridgeId: number;
}
