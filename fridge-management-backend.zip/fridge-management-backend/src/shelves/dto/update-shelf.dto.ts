// update-shelf.dto.ts
export class UpdateShelfDto {
  shelfName?: string;
  fridgeId?: number;
}
